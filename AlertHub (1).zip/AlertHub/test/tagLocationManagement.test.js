import { postTag, getTag, postLocation, getLocation } from "../Controllers/PostController.js";
import TagModel from "../Models/tagModel.js";
import LocationModel from "../Models/locationModel.js";

jest.mock("../Models/tagModel.js");
jest.mock("../Models/locationModel.js");

describe("Tag Management Tests", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("Success: create a new tag", async () => {
    // This test should pass
    TagModel.create = jest.fn().mockResolvedValue({});
    const req = { body: { tag: "testTag" } };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    await postTag(req, res);

    expect(TagModel.create).toHaveBeenCalledWith({ tag: "testTag" });
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith("Success");
  });

  test("Success: get all tags", async () => {
    // This test should pass
    const mockTags = [{ tag: "tag1" }, { tag: "tag2" }];
    TagModel.find = jest.fn().mockResolvedValue(mockTags);
    const req = {};
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    await getTag(req, res);

    expect(TagModel.find).toHaveBeenCalled();
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith(mockTags);
  });

  test("Failure: create a new tag fails", async () => {
    // This test should pass
    TagModel.create = jest.fn().mockRejectedValue(new Error("Failed"));
    const req = { body: { tag: "failTag" } };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    await postTag(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith("Failed");
  });
});

describe("Location Management Tests", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("Success: create a new location", async () => {
    // This test should pass
    LocationModel.create = jest.fn().mockResolvedValue({});
    const req = { body: { location: "testLocation" } };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    await postLocation(req, res);

    expect(LocationModel.create).toHaveBeenCalledWith({ location: "testLocation" });
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith("Success");
  });

  test("Success: get all locations", async () => {
    // This test should pass
    const mockLocations = [{ location: "loc1" }, { location: "loc2" }];
    LocationModel.find = jest.fn().mockResolvedValue(mockLocations);
    const req = {};
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    await getLocation(req, res);

    expect(LocationModel.find).toHaveBeenCalled();
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith(mockLocations);
  });
});
