import { upvotePost, downvotePost } from "../Controllers/PostController.js";
import ReportPostModel from "../Models/postModel.js";

jest.mock("../Models/postModel.js");

describe("Upvote and Downvote Post Tests", () => {
  const mockPostId = "post123";
  const mockUserId = "user123";

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("Success: upvote a post that user has not upvoted before", async () => {
    // This test should pass
    const mockPost = {
      upvotes: [],
      downvotes: [],
      save: jest.fn(),
    };
    ReportPostModel.findById = jest.fn().mockResolvedValue(mockPost);

    const req = { params: { id: mockPostId }, body: { userId: mockUserId } };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    await upvotePost(req, res);

    expect(mockPost.upvotes).toContain(mockUserId);
    expect(mockPost.downvotes).not.toContain(mockUserId);
    expect(mockPost.save).toHaveBeenCalled();
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith("Post upvoted");
  });

  test("Success: downvote a post that user has not downvoted before", async () => {
    // This test should pass
    const mockPost = {
      upvotes: [mockUserId],
      downvotes: [],
      save: jest.fn(),
    };
    ReportPostModel.findById = jest.fn().mockResolvedValue(mockPost);

    const req = { params: { id: mockPostId }, body: { userId: mockUserId } };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    await downvotePost(req, res);

    expect(mockPost.downvotes).toContain(mockUserId);
    expect(mockPost.upvotes).not.toContain(mockUserId);
    expect(mockPost.save).toHaveBeenCalled();
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith("Post downvoted");
  });

  test("Failure: upvote a post that user already upvoted", async () => {
    // This test should fail (user already upvoted)
    const mockPost = {
      upvotes: [mockUserId],
      downvotes: [],
      save: jest.fn(),
    };
    ReportPostModel.findById = jest.fn().mockResolvedValue(mockPost);

    const req = { params: { id: mockPostId }, body: { userId: mockUserId } };
    const res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn(),
    };

    await upvotePost(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith("User already upvoted");
  });
});
