import express from "express";
import { createSos, getSosCalls } from "../Controllers/sosController.js";

const router = express.Router();

router.post("/", createSos);
router.get("/", getSosCalls);

export default router;
