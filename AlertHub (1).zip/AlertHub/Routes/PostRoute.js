import express from "express";
import { createPost, deletePost, getPost, getTimelinePosts, likePost, updatePost, getAllPosts, getIncidentFilteredPosts, postReporting, upvotePost, downvotePost, saveDraft, getDrafts, deleteDraft, updateDraft } from "../Controllers/PostController.js";
const router = express.Router();

router.post('/', createPost);
router.post('/post-reporting', postReporting);
router.post('/save-draft', saveDraft);
router.get('/', getAllPosts);
router.get('/incidentfilter', getIncidentFilteredPosts);
router.get('/get-drafts', getDrafts);
router.get('/:id', getPost);
router.put('/:id', updatePost);
router.put('/update-draft/:id', updateDraft);
router.delete("/:id", deletePost);
router.delete("/delete-draft/:id", deleteDraft);
router.put("/:id/like", likePost);
router.put("/:id/upvote", upvotePost);
router.put("/:id/downvote", downvotePost);
router.get("/:id/timeline", getTimelinePosts);

export default router;
