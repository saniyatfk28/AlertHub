import express from "express";
import { getTag, postTag } from "../Controllers/PostController.js";

const router = express.Router();

router.get("/", getTag);
router.post("/", postTag);

export default router;
