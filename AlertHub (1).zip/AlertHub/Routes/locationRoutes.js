import express from "express";
import { getLocation, postLocation } from "../Controllers/PostController.js";

const router = express.Router();

router.get("/", getLocation);
router.post("/", postLocation);

export default router;
